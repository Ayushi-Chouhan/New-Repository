//Assignment
class Shape
{
public:
void circle()
{
chooseColor();
print circle
}
void square()
{
chooseColor();
print square
}
void triangle()
{
chooseColor();
print trianle;
}
private:
void chooseColor()
{

Enter 1 for red 2 for green and 3 for blue
cin>>col;
switch(col)
{
case 1:
print red;
break;
case 2:
print green;
break;
case 3:
print blue;
break;
}
}
};



int main()
{
Shape s;
Enter 1 for draw circle,2 for draw square and 3 for draw triangle
x
switch(x)
{
case 1:
s.circle();
break;
case 2:
s.square();
break;
case 3:
s.triangle();
break;

}
}
