#include<iostream>
using namespace std;

class Foo
{

public:
static void m()
{
cout<<"Hello I am static method"<<endl;
}
};


int main()
{
Foo::m();
Foo::m();
}
